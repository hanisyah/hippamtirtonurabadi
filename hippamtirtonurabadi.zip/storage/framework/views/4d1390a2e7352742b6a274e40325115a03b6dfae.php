<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
            <h4>Data Total Tagihan</h4>
            </div>

            

            <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover" id="tableExport" style="width:100%;">
                <thead>
                    <tr>
                    <th>No </th>
                    <th>Kode Meteran </th>
                    <th>Nama Pelanggan</th>
                    <th>Tahun</th>
                    <th>Bulan</th>
                    <th>Tarif Golongan</th>
                    <th>Jumlah Meteran Kemarin</th>
                    <th>Jumlah Meteran</th>
                    <th>Sub Total</th>
                    <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $totalTagihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($tag->tagihan->pelanggan->kodeMeter); ?></td>
                    <td><?php echo e($tag->tagihan->pelanggan->namaPelanggan); ?></td>
                    <td><?php echo e($tag->tagihan->tahun); ?></td>
                    <td><?php echo e($tag->tagihan->bulan); ?></td>
                    <td><?php echo e($tag->tagihan->golongan->tarif); ?></td>
                    <td><?php echo e($tag->tagihan->jumlah_meter_kemarin); ?></td>
                    <td><?php echo e($tag->tagihan->jumlahMeter); ?></td>
                    <td><?php echo e($tag->subTotal); ?></td>
                    <td>
                        <a href="<?php echo e(url('/totaltagihan-pdf/'.$tag->idTotalTagihan)); ?>" target="_blank" rel="noopener noreferrer" class="on-default edit-row btn btn-primary" ><i class="fas fa-file-pdf" title="Cetak PDF"></i></a>
                        <a href="<?php echo e(url('/tagihanwa/'.$tag->idTotalTagihan)); ?>" title="Kirim data PDF ke whatsapp" rel="noopener noreferrer" class="on-default edit-row btn btn-success" ><i class="
                            fab fa-whatsapp"></i></a>
                        <form action="<?php echo e(url('/totalTagihan/'.$tag->idTotalTagihan)); ?>" method="get" class="d-inline">

                            <button class="on-default edit-row btn btn-danger" onclick="return confirm('Apakah anda yakin akan menghapus nya?');" ><i class="fa fa-trash"></i></button>
                        </form>
                    </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hippamtirtonurabadi\resources\views/totaltagihan/index.blade.php ENDPATH**/ ?>