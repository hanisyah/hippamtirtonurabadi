<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-body">
        <div class="row">
            <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4>Update Data User</h4>
                </div>
                <div class="card-body">

                <form action="<?php echo e(url('/user/'.$user->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('patch'); ?>
                    <input type="hidden" name="id" id="id">
                    <div class="form-group row mb-4">
                        <input type="hidden" name="pegawai_id" value="<?php echo e($user->pegawai->idPegawai); ?>">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Nama Pegawai</label>
                        <div class="col-sm-12 col-md-7">
                            <input class="form-control" id="name" name="nama_pegawai" disabled placeholder="Nama user" value="<?php echo e($user->pegawai->namaPegawai); ?>">
                        </div>
                    </div>
                    <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Kode Pegawai</label>
                        <div class="col-sm-12 col-md-7">
                            <input type="text" class="form-control" autocomplete="off" id="kodePegawai" name="kodePegawai" placeholder="kodePegawai" value="<?php echo e($user->pegawai->kodePegawai); ?>" readonly>
                        </div>
                    </div>
                    <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Username</label>
                        <div class="col-sm-12 col-md-7">
                            <input type="text" class="form-control" autocomplete="off" id="username" name="username" placeholder="Username" value="<?php echo e($user->username); ?>" >
                        </div>
                    </div>
                    <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Ganti Password (opsional)</label>
                        <div class="col-sm-12 col-md-7">
                            <input type="password" class="form-control" id="password" name="password" placeholder="Password" value="">
                        </div>
                    </div>
                    
                    <div class="form-group row mb-4">
                            <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Level</label>
                            <div class="col-sm-12 col-md-7">
                                <select id="level" type="text" class="form-control custom-select-value" name="level"> <option value="<?php echo e($user->level); ?>"> <?php echo e($user->level); ?></option>
                                    <option value="superadmin">Super Admin</option>
                                    <option value="admin">Admin</option>
                                    <option value="pencatat">Pencatat</option>
                                </select>
                            </div>
                        </div>
                    <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                        <div class="col-sm-12 col-md-7">
                        <a class="on-default edit-row btn btn-danger" href="<?php echo e(url('/user/')); ?>"> Kembali</a>
                        <button class="btn btn-primary">Simpan</button>
                        </div>
                    </div>
                </form>
                </div>
            </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hippamtirtonurabadi\resources\views/user/update.blade.php ENDPATH**/ ?>