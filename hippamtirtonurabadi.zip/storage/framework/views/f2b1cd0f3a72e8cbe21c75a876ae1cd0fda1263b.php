<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<!-- MAKA TAMPILKAN ALERT SUCCESS -->
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<!-- KETIKA ADA SESSION ERROR  -->
<?php if(session('error')): ?>
<!-- MAKA TAMPILKAN ALERT DANGER -->
    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
            <h4>Data User</h4>
            </div>

            <div style="text-align:right; margin-right:10px">
                <a href="/user/create" class="on-default btn btn-success" ><i class="fa fa-plus-circle"> Add Data</i> </a>
            </div>

            <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover" id="tableExport" style="width:100%;">
                <thead>
                    <tr>
                    <th>No</th>
                    <th>Nama Pegawai</th>
                    <th>Username</th>
                    <th>Nama</th>
                    
                    <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($usr->pegawai->namaPegawai); ?></td>
                    <td><?php echo e($usr->username); ?></td>
                    <td><?php echo e($usr->name); ?></td>
                    
                    <td>
                        <a href="<?php echo e(url('/user/'.$usr->id.'/edit')); ?>" class="on-default edit-row btn btn-warning" ><i class="far fa-edit"></i></a>
                        <form action="<?php echo e(url('/user/'.$usr->id)); ?>" method="post" class="d-inline">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <button class="on-default edit-row btn btn-danger" onclick="return confirm('Apakah anda yakin akan menghapus nya?');" ><i class="fa fa-trash"></i></button>
                        </form>
                    </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hippamtirtonurabadi\resources\views/user/index.blade.php ENDPATH**/ ?>