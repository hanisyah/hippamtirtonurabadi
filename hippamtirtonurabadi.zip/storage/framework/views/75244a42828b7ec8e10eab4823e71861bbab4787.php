<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
            <h4>Data Tagihan</h4>
            </div>

            <div class="card-body">
            <form action="<?php echo e(url('/tagihan')); ?>" id="form_range" method="get">
                <div class="form-group">
                    <input type="text" class="form-control" name="dates" />
                </div>
            </form>
            <div class="table-responsive">
                <table class="table table-striped table-hover" id="tableExport" style="width:100%;">
                <thead>
                    <tr>
                    <th>No </th>
                    <th>Kode Meteran </th>
                    <th>Nama Pelanggan</th>
                    <th>Golongan</th>
                    <th>Tahun</th>
                    <th>Bulan</th>
                    <th>Tanggal Catat</th>
                    <th>Jumlah Meteran Kemarin</th>
                    <th>Jumlah Meteran</th>
                    <th>Foto Meteran</th>
                    <th>Pegawai Pencatat</th>
                    <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tagihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($tag->pelanggan->kodeMeter); ?></td>
                    <td><?php echo e($tag->pelanggan->namaPelanggan); ?></td>
                    <td><?php echo e($tag->golongan->namaGolongan); ?></td>
                    <td><?php echo e($tag->tahun); ?></td>
                    <td><?php echo e($tag->bulan); ?></td>
                    <td><?php echo e(Carbon\Carbon::parse($tag->tanggalCatat)->translatedFormat('l, d F Y')); ?></td>
                    <td><?php echo e($tag->jumlah_meter_kemarin); ?></td>
                    <td><?php echo e($tag->jumlahMeter); ?></td>
                    <td>
                        
                        <a href="<?php echo e(asset('img/'. $tag->fotoMeteran)); ?>" target="_blank" rel="noopener noreferrer">Lihat Meter Air</a>
                    </td>
                    <td><?php echo e($tag->pegawai->namaPegawai); ?></td>
                    <td>
                        
                        <form action="<?php echo e(url('/tagihan/'.$tag->idTagihan)); ?>" method="post" class="d-inline">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                        <button class="on-default edit-row btn btn-danger" onclick="return confirm('Apakah anda yakin akan menghapus nya?');" ><i class="fa fa-trash"></i></button>
                        </form>
                    </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>

$('input[name="dates"]').daterangepicker();
$('input[name="dates"]').on('apply.daterangepicker', function() {
  $('#form_range').submit();
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hippamtirtonurabadi\resources\views/tagihan/index.blade.php ENDPATH**/ ?>