<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-body">
        <div class="row">
            <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4>Input Data Tagihan</h4>
                </div>
                <div class="card-body">
                <form action="<?php echo e(url('/tagihan')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Nama Pelanggan</label>
                        <div class="col-sm-12 col-md-7">
                            
                            <select class="form-control" placeholder="-- Select Nama Pelanggan --" id="idPelanggan" name="idPelanggan" onchange="setInput(this)"  required>
                                <option value selected="selected">-- Pilih Pelanggan --</option>
                                <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plgn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($plgn->idPelanggan); ?>"><?php echo e($plgn->namaPelanggan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Kode Meter</label>
                        <div class="col-sm-12 col-md-7">
                            <input type="text" class="form-control" id="kodeMeter" name="kodeMeter" placeholder="Kode Meter">
                            
                        </div>
                    </div>
                    <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Golongan</label>
                        <div class="col-sm-12 col-md-7">
                            
                            <select class="form-control" placeholder="-- Select Golongan --" id="idGolongan" name="idGolongan"  required>
                                <option value selected="selected">-- Pilih Golongan --</option>
                                <?php $__currentLoopData = $golongan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plgn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($plgn->idGolongan); ?>"><?php echo e($plgn->namaGolongan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Tahun</label>
                        <div class="col-sm-12 col-md-7">
                            <input type="number" class="form-control" autocomplete="off" id="tahun" name="tahun" placeholder="Tahun">
                        </div>
                    </div>
                    <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Bulan</label>
                        <div class="col-sm-12 col-md-7">
                            <input type="text" class="form-control" autocomplete="off" id="bulan" name="bulan" placeholder="Bulan">
                        </div>
                    </div>
                    <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Tanggal Catat</label>
                        <div class="col-sm-12 col-md-7">
                            <input type="date" class="form-control" autocomplete="off" id="tanggalCatat" name="tanggalCatat" placeholder="Tanggal Catat">
                        </div>
                    </div>
                    <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Jumlah Meter Kemarin</label>
                        <div class="col-sm-12 col-md-7">
                            <input type="number" class="form-control" autocomplete="off" id="jumlahMeterKemarin" name="jumlahMeterKemarin" placeholder="Jumlah Meter Kemarin">
                        </div>
                    </div>
                    <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Jumlah Meter</label>
                        <div class="col-sm-12 col-md-7">
                            <input type="number" class="form-control" autocomplete="off" id="jumlahMeter" name="jumlahMeter" placeholder="Jumlah Meter">
                        </div>
                    </div>
                    <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Foto Meteran</label>
                        <div class="col-sm-12 col-md-7">
                            
                            
                            <input type="file" name="fotoMeteran" id="fotoMeteran" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Pegawai Pencatat</label>
                        <div class="col-sm-12 col-md-7">
                            <select class="form-control" id="idPegawai" name="idPegawai"  required>
                                <option value selected="selected">-- Pilih Pegawai --</option>
                                <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pgw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($pgw->idPegawai); ?>"><?php echo e($pgw->namaPegawai); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                        <div class="col-sm-12 col-md-7">
                        <button class="btn btn-primary">Simpan</button>
                        </div>
                    </div>
                </form>
                </div>
            </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>


<script>
    function setInput(result) {
        var value = result.value;

        $.ajax({
            url: '<?php echo e(url('/tagihan/get-data/')); ?>',
            type: 'POST',
            data: 'idPelanggan=' + value,
            dataType: 'JSON',
            success: function(response){
                $("#kodeMeter").val(response.result.kodeMeter);
                $("#idGolongan").val(response.result.golongan_id).change();
            }
        })
    }
</script>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hippamtirtonurabadi\resources\views/tagihan/create.blade.php ENDPATH**/ ?>