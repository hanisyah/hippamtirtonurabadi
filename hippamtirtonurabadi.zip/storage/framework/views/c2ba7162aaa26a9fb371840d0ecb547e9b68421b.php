<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-body">
        <div class="row">
            <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4>Input Data User</h4>
                </div>
                <div class="card-body">
                <form action="<?php echo e(url('/user')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Nama Pegawai</label>
                        <div class="col-sm-12 col-md-7">
                            <select class="form-control" placeholder="-- Select Nama Pegawai --" id="idPegawai" name="idPegawai" onchange="setInput(this)" value="<?php echo e(old('idPegawai')); ?>">
                                <option value selected="selected">-- Pilih Pegawai --</option>
                                <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pgw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($pgw->idPegawai); ?>" <?php echo e(old('idPegawai') == "$pgw->idPegawai" ? "selected" : ""); ?>><?php echo e($pgw->namaPegawai); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Kode Pegawai</label>
                        <div class="col-sm-12 col-md-7">
                            <input type="text" class="form-control" id="kodePegawai" name="kodePegawai" placeholder="Kode Pegawai" value="<?php echo e(old('kodePegawai')); ?>" readonly>
                        </div>
                    </div>
                    <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Username</label>
                        <div class="col-sm-12 col-md-7">
                            <input type="text" class="form-control" autocomplete="off" id="username" name="username" placeholder="Username" value="<?php echo e(old('username')); ?>">
                        </div>
                    </div>
                    <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Password</label>
                        <div class="col-sm-12 col-md-7">
                            <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid:'' <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="off" id="password" name="password" placeholder="Password" value="<?php echo e(old('password')); ?>">
                        </div>
                    </div>
                    <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Konfirmasi Password</label>
                        <div class="col-sm-12 col-md-7">
                            <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid:'' <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="off" id="password_confirmation" name="password_confirmation" placeholder="Konfirmasi Password" value="<?php echo e(old('password')); ?>">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger">
                                    Password yang dimasukkan salah
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Level</label>
                        <div class="col-sm-12 col-md-7">
                            <div class="form-select-list">
                            <select id="level" type="text" class="form-control custom-select-value" name="level" value="<?php echo e(old('level')); ?>">
                                <option>-- Pilih Level Admin --</option>
                                <option value="superadmin" <?php echo e(old('level') == "superadmin" ? "selected" : ""); ?>>Super Admin</option>
                                <option value="admin" <?php echo e(old('level') == "admin" ? "selected" : ""); ?>>Admin</option>
                                <option value="pencatat" <?php echo e(old('level') == "pencatat" ? "selected" : ""); ?>>Pencatat</option>
                            </select>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                        <div class="col-sm-12 col-md-7">
                        <button class="btn btn-primary">Simpan</button>
                        </div>
                    </div>
                </form>
                </div>
            </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<script>
    function setInput(result) {
        var value = result.value;

        $.ajax({
            url: '<?php echo e(url('/pegawai/get-data/')); ?>',
            type: 'POST',
            data: 'idPegawai=' + value,
            dataType: 'JSON',
            success: function(response){
                $("#kodePegawai").val(response.result.kodePegawai);
            }
        })
    }
</script>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hippamtirtonurabadi\resources\views/user/create.blade.php ENDPATH**/ ?>