@extends('master')
@section('content')

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
            <h4>Detail Data Tagihan</h4>
            </div>

            <div style="text-align:right; margin-right:10px">
                <a href="" class="on-default btn btn-success" ><i class="fa fa-plus-circle"> Add Data</i> </a>
            </div>

            <div class="card-body">

            </div>
        </div>
    </div>
</div>
@endsection
