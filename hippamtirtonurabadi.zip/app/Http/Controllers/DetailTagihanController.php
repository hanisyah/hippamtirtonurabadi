<?php

namespace App\Http\Controllers;

use App\DetailTagihan;
use Illuminate\Http\Request;

class DetailTagihanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\DetailTagihan  $detailTagihan
     * @return \Illuminate\Http\Response
     */
    public function show(DetailTagihan $detailTagihan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\DetailTagihan  $detailTagihan
     * @return \Illuminate\Http\Response
     */
    public function edit(DetailTagihan $detailTagihan)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\DetailTagihan  $detailTagihan
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DetailTagihan $detailTagihan)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\DetailTagihan  $detailTagihan
     * @return \Illuminate\Http\Response
     */
    public function destroy(DetailTagihan $detailTagihan)
    {
        //
    }
}
